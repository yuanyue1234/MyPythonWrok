import os

# os.remove('test2.txt') # 删除文件 当删除文件不存在时,会报错
os.rename('test2.txt', 'test_rename.txt')

